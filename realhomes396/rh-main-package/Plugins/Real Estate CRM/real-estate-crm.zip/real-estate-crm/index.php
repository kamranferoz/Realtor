<?php
//Wisdom is not a product of schooling but of the lifelong attempt to acquire it ― Albert Einstein.

# Easy Real Estate #

This plugin provides plugin territory functionality for Real Homes theme.

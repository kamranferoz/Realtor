<?php
/**
 * Single Agent
 *
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/agent/single/agent' );

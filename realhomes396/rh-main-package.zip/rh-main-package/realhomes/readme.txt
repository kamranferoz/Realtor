Please consult the documentation for detailed instructions.

For General WordPress Issues you can search your issue in Google. As there are thousands of helping articles and forum threads out there to help WordPress users.

In case of any theme specific question, Please signup to our support website https://support.inspirythemes.com/login-register/ and ask your question over there https://support.inspirythemes.com/ask-question/ .

For customisation you can consider hiring our services https://inspirythemes.com/theme-customization/

<?php
/**
 * Sidebar: Property Listing
 *
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/sidebar/property-listing' );

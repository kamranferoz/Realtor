<?php
/**
 * Taxonomy: Property Status
 *
 * @package realhomes
 * @subpackage modern
 */

// Use Common Taxonomy Template.
get_template_part( 'assets/modern/partials/taxonomy/common' );

<div class="rh_sticky_header_container">
    <div class="sticky_header_box">
        <div class="header_logo">
			<?php get_template_part( 'assets/modern/partials/header/site-logo' ); ?>
        </div>
        <div class="main-menu">
			<?php get_template_part( 'assets/modern/partials/header/menu-list-large-screens' ); ?>
        </div>
        <div class="submit_property">
	        <?php get_template_part( 'assets/modern/partials/header/user-phone' ); ?>
	        <?php get_template_part( 'assets/modern/partials/header/user-email' ); ?>
			<?php get_template_part( 'assets/modern/partials/header/submit-property' ); ?>
        </div>
    </div>
</div>

